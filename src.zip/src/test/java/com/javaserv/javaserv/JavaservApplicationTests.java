package com.javaserv.javaserv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaservApplicationTests {

	@Test
	void contextLoads() {
		System.out.println("testing text");
	}
@Test
	void test(){

		System.out.println("testing two");
	}


}
