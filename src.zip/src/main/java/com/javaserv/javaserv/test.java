package com.javaserv.javaserv;

public class test {
    public String name;
    public int age;
    public test(String nm, int ag){name = nm; age=ag;}
}
